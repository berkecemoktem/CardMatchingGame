package Constants;
import javax.swing.JOptionPane;

//This class provides us to use some constant messages we use frequently.
//Since, we use them frequently they were built as static

public class Helper {
	
	public static String loginSuccess = "Login is successful. Welcome, ";
	public static String loginNotSuccess = "Nickname field cannot be empty!";

	public static void loginSuccessMesage(String userName) {
		 JOptionPane.showMessageDialog(null, loginSuccess + " " + userName);
	}
	public static void loginNotSuccessMesage() {
		 JOptionPane.showMessageDialog(null, loginNotSuccess);
	}
}
