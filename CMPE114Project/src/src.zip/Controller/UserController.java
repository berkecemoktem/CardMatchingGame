package Controller;


import javax.swing.JTextField;

import Model.IUserService;

//this is a business class for user entity
public class UserController implements IUserService {

	@Override
	public boolean checkLoginIfSuccessful(JTextField textField) {
		if(textField.getText().toString().length() == 0) {
			return false;
		}
		else {
			return true;
		}
	}
}

	
		

