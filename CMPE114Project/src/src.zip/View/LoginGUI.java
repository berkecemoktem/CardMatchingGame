package View;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Constants.Helper;
import Controller.UserController;
import Model.User;
import jaco.mp3.player.MP3Player;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import javax.swing.UIManager;
import javax.swing.JToolBar;

//This is a login page asks for user nickname and calls necessary methods to validate.

public class LoginGUI extends JFrame {

	User user;
	//ArrayList<User> userList = new ArrayList<User>();
	private JPanel contentPane;
	private JTextField nickname_text;
	JFrame gameFrame = new JFrame();
	private JTextField txtHowToPlay;

	/**
	 * Launch the application.
	 */
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginGUI frame = new LoginGUI();
					frame.setTitle("Card Memory Game");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginGUI() {
		UserController userController = new UserController();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 867, 489);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Nickname: ");
		lblNewLabel_1.setBounds(10, 233, 103, 13);
		contentPane.add(lblNewLabel_1);
		
		nickname_text = new JTextField();
		nickname_text.setBounds(10, 255, 103, 19);
		contentPane.add(nickname_text);
		nickname_text.setColumns(10);
		
		JButton btn_start = new JButton("Start");
		btn_start.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(userController.checkLoginIfSuccessful(nickname_text)) {
					user = new User(nickname_text.getText());
					//userList.add(user);
					Helper.loginSuccessMesage(user.getNickname());
					dispose();
					Board board = new Board();
					board.setVisible(true);
				}
				else {
					Helper.loginNotSuccessMesage();
					
				}	 
				
			}
		});
		btn_start.setBounds(10, 289, 85, 21);
		contentPane.add(btn_start);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\oktem\\Desktop\\memory.png"));
		lblNewLabel.setBounds(145, 0, 698, 452);
		contentPane.add(lblNewLabel);

		txtHowToPlay = new JTextField();
		txtHowToPlay.setBackground(Color.PINK);
		txtHowToPlay.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { try {

				URI uri= new URI("https://www.helpmykidlearn.ie/activities/5-7/detail/memory-card-game");

				java.awt.Desktop.getDesktop().browse(uri);

			} catch (Exception e1) {

				e1.printStackTrace();
			}
			}
		});
		
		txtHowToPlay.setText("How to play?");
		txtHowToPlay.setBounds(10, 315, 85, 19);
		contentPane.add(txtHowToPlay);
		txtHowToPlay.setColumns(10);
	}
	/*public void playLoginSong() {
		try {
			AudioInputStream audioInputStream;
			File file = new File("loginMusic.wav");
			audioInputStream = AudioSystem.getAudioInputStream(file);
			Clip line;
			line = (Clip) AudioSystem.getLine(new DataLine.Info(Clip.class, audioInputStream.getFormat()));
			line.open(audioInputStream);
			line.start();
			line.drain();
			audioInputStream.close();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}*/
}
